# Projectivy Launcher special device configuration

This repository contains configuration files for a few devices, tv/projectors from the Xiaomi ecosystem.
At the time it was know as Projectivy Tools, it offered several features related to :
- rooting
- installing custom recovery
- installing play services
- disabling stock apps
- replacing the launcher
- installing third party apps

These features are still available in the recent versions of Projectivy Launcher (4.x).
The config files (including the "generic" one) are also used to host the path to the lastest version of Projectivy Launcher, in order to provide an update mean in case it has not been installed from Google Play.
